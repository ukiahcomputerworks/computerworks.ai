---
layout: page
page_title: Contact Us
title: Contact Us
permalink: /contact/
published: true
---

<p>Call <a class="phone-cta" href="tel:7074628275">(707) 462-8275</a> or fill out the form below with any questions &mdash; thank you.</p>

<div id="wufoo-z9cbgzd0wxkahu"></div>
<script type="text/javascript">
var z9cbgzd0wxkahu;
(function(d, t) {
  var s = d.createElement(t), options = {
    'userName':'computerworksofukiah',
    'formHash':'z9cbgzd0wxkahu',
    'autoResize':true,
    'height':'557',
    'async':true,
    'host':'wufoo.com',
    'header':'hide',
    'ssl':true
  };
  s.src = 'https://www.wufoo.com/scripts/embed/form.js';
  s.onload = s.onreadystatechange = function() {
    var rs = this.readyState;
    if (rs && rs != 'complete' && rs != 'loaded') return;
    try { z9cbgzd0wxkahu = new WufooForm(); z9cbgzd0wxkahu.initialize(options); z9cbgzd0wxkahu.display(); } catch (e) {}
  };
  var scr = d.getElementsByTagName(t)[0], par = scr.parentNode;
  par.insertBefore(s, scr);
})(document, 'script');
</script>
